﻿namespace Orchard.ContentTypes.ViewModels {
    public class RemovePartViewModel {
        public string Name { get; set; }
        public EditTypeViewModel Type { get; set; }
    }
}

﻿using Contrib.MediaPickerField.Settings;

namespace Contrib.MediaPickerField.ViewModels {
    public class MediaPickerFieldViewModel {
        public MediaPickerFieldSettings Settings { get; set; }
        public Fields.MediaPickerField Field { get; set; }
    }
}
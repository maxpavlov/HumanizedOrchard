﻿namespace Orchard.Media.Models {
    public class FolderNavigation {
        public string FolderName { get; set; }
        public string FolderPath { get; set; }
    }
}
